# DeFi-Exchange

一个基于以太坊的去中心化交易所（DEX）应用，支持ERC20代币与ETH的交易。

## 项目特性

- 🔄 去中心化交易：基于智能合约的完全去中心化交易
- 💰 多币种支持：支持ETH和ERC20代币交易
- 📊 实时余额查询：钱包和交易所余额实时显示
- 📝 订单管理系统：创建、取消和执行交易订单
- 🔐 区块链安全：所有交易记录在区块链上，不可篡改
- 🎨 现代化UI：基于React和Ant Design的优雅界面

## 技术栈

### 前端
- **React 19** - 用户界面框架
- **Redux Toolkit** - 状态管理
- **Ant Design** - UI组件库
- **Web3.js** - 区块链交互

### 后端
- **Solidity** - 智能合约开发
- **Truffle** - 合约编译和部署框架
- **OpenZeppelin** - 安全合约库

### 区块链
- **Ethereum** - 区块链网络
- **ERC20** - 代币标准

## 项目结构

```
├── contracts/          # 智能合约
│   ├── Exchange.sol    # 交易所合约
│   ├── KerwinToken.sol # ERC20代币合约
│   └── ...
├── src/               # 前端代码
│   ├── components/    # React组件
│   ├── redux/         # 状态管理
│   └── views/         # 页面组件
├── migrations/        # 合约部署脚本
└── test/             # 测试文件
```

## 快速开始

### 环境要求
- Node.js >= 16
- Truffle
- Ganache (本地以太坊测试网)
- MetaMask钱包

### 安装依赖
```bash
npm install
```

### 启动本地区块链
```bash
# 安装并启动Ganache
npm install -g ganache-cli
ganache-cli
```

### 部署合约
```bash
truffle migrate
```

### 启动前端应用
```bash
npm start
```

访问 http://localhost:3000 查看应用

## 使用说明

1. **连接钱包**：使用MetaMask连接到本地网络
2. **查看余额**：实时显示钱包和交易所中的资产
3. **充值**：将代币存入交易所
4. **交易**：创建买卖订单并执行交易
5. **提现**：从交易所提取资产

## 开发说明

### 合约开发
```bash
# 编译合约
truffle compile

# 运行测试
truffle test

# 部署到测试网
truffle migrate --network development
```

### 前端开发
```bash
# 启动开发服务器
npm start

# 构建生产版本
npm run build

# 运行测试
npm test
```

## 许可证

本项目采用 MIT 许可证。